package com.airlinesystem.airlines.service;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.airlinesystem.airlines.domain.Admin;
import com.airlinesystem.airlines.domain.User;
import com.airlinesystem.airlines.repository.AdminRepository;
import com.airlinesystem.airlines.repository.UserRepository;

@Service
public class AdminService {

	@Autowired
	private AdminRepository repository;
	
	
	
	
	public AdminService(AdminRepository repository) {
		super();
		this.repository = repository;
	}


	public Admin Signin(String email, String password) {
		Admin admin= repository.findByEmailAndPassword(email, password);
		return admin;
	}

	
}
