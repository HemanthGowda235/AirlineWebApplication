package com.airlinesystem.airlines.service;



import java.util.Date;
import java.util.List;


import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.data.web.SpringDataWebProperties.Pageable;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.airlinesystem.airlines.domain.Airlinedetails;
import com.airlinesystem.airlines.domain.User;
import com.airlinesystem.airlines.repository.AirlinedetailsRepository;
import com.airlinesystem.airlines.repository.UserRepository;

@Service
public class AirlinedetailsService {

	@Autowired
	private AirlinedetailsRepository repository;
	
	@Autowired
	private UserRepository userrepository;

	public AirlinedetailsService(AirlinedetailsRepository repository) {
		super();
		this.repository = repository;
	}
	
    @Transactional
	public void save(Airlinedetails airlinedetails) {
		 repository.save(airlinedetails);
	}
	
    
    public void delete(Airlinedetails airlinedetails) {
		 repository.delete(airlinedetails);
	}
	


	public Airlinedetails get(int id) {
	
		return repository.findById(id).get();
	}
	
	 public List<Airlinedetails> getAll(){
			return repository.findAll();
	    	 
	     }

	public List<Airlinedetails> findById(int id) {
		
		return repository.findByUserId(id);
	}
	
	public List<Airlinedetails> findByKeyWord(String keyword){
		return repository.findByKeyWord(keyword);
	}
	
	public List<Airlinedetails> findByKeyWords(String keywords){
		return repository.findByKeyWords(keywords);
	}
	
	
	
	
	
	public List<Airlinedetails> findAllByFlightDate(Date flightDate){
		return repository.findAllByFlightDate(flightDate);
	}

	

	// public List<Airlinedetails> findByFlightNameAndSourceAndDate(String flightName, String source, Date date){
	//	return repository.findByFlightNameAndSourceAndDate(flightName, source, date);
	
//}
     public Page<Airlinedetails> findPaginated(int pageNo, int pageSize,String sortField,String  sortDirection){
      Sort sort = sortDirection.equalsIgnoreCase(Sort.Direction.ASC.name()) ? Sort.by(sortField).ascending() :
       Sort.by(sortField).descending();
      org.springframework.data.domain.Pageable pageable = PageRequest.of(pageNo , pageSize);
        return repository.findAll(pageable);
    	 
     }

	//public void remove(Airlinedetails details) {
	//	repository.remove(details);
		
	//}
	
}



