package com.airlinesystem.airlines.controller;

import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.airlinesystem.airlines.domain.Admin;
import com.airlinesystem.airlines.domain.User;
import com.airlinesystem.airlines.repository.AdminRepository;
import com.airlinesystem.airlines.service.AdminService;

@Controller
public class AdminController {

	@Autowired
	private AdminRepository repository;

	@Autowired
	private AdminService service;

	public AdminController(AdminRepository repository, AdminService services) {
		super();
		this.repository = repository;
		this.service = service;
	}

	

	 @RequestMapping("/adminlogin")
	  public ModelAndView showLoginForm(@ModelAttribute("admin") Admin admin ) { 
		  ModelAndView ma = new ModelAndView();
		 ma.setViewName("adminlogin");
		 ma.addObject("admin", new Admin());
	      return ma;
	      }
	 
	 @RequestMapping("/adminpage")
	  public ModelAndView showAdminPage(@ModelAttribute("admin") Admin admin ) { 
		  ModelAndView ma = new ModelAndView();
		 ma.setViewName("adminpage");
		 ma.addObject("admin", new Admin());
	      return ma;
	      }
	 

	@PostMapping("/adminlogin")
	public String signin(@ModelAttribute("admin") Admin admin) {
		Admin a = service.Signin(admin.getEmail(), admin.getPassword());
		System.out.println(a.getEmail());
		System.out.println(a.getPassword());
		if (Objects.nonNull(a)) {
			return "redirect:/adminpage";

		} 
		else {
			return "redirect:/adminlogin?no";
		}

			
	
	
	}
	
	
	/*
	 * @RequestMapping(value = "/adminlogin", method = RequestMethod.GET) public
	 * String adminspage(Model model) { ModelAndView m = return "/adminlogin"; }
	 */
	 
	   
	  @RequestMapping(value = "/adminlogin", method = RequestMethod.GET) 
	  public ModelAndView adminspage(@ModelAttribute("admin") Admin admin ) { 
		  ModelAndView maa = new ModelAndView();
		 maa.setViewName("adminlogin");
		 maa.addObject("admin", new Admin());
	      return maa;
	      }
	


	  @RequestMapping("/home")
	  public ModelAndView showhomePage(@ModelAttribute("admin") Admin admin ) { 
		  ModelAndView ma = new ModelAndView();
		 ma.setViewName("index");
		 ma.addObject("admin", new Admin());
	      return ma;
	      }
	  
	  @RequestMapping("/adminsignout")
	  public ModelAndView signoutPage(@ModelAttribute("admin") Admin admin ) { 
		  ModelAndView ma = new ModelAndView();
		 ma.setViewName("adminlogin");
		// ma.addObject("admin", new Admin());
	      return ma;
	      }
	  
	  
	  
	  
	  
	  @RequestMapping("/fbook")
		public ModelAndView dashBoard(@ModelAttribute("admin") Admin admin) {
		  ModelAndView ma = new ModelAndView();
		  ma.setViewName("flightbookings");
				return ma;

		}
		
	
}
