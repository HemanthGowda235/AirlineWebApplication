package com.airlinesystem.airlines.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;


import com.airlinesystem.airlines.domain.Airlinedetails;
import com.airlinesystem.airlines.domain.User;



	@Repository
	public interface AirlinedetailsRepository extends  JpaRepository<Airlinedetails, Integer>{

		
		
		@Query("SELECT a FROM Airlinedetails a inner join a.users u where u.id= ?1")
		List<Airlinedetails> findByUserId(int Id);

		//@Query( value = "SELECT * from flightsbookings f where f.destination like %:keyword%" , nativeQuery = true )
		@Query(value = "SELECT * FROM flightsbookings p WHERE CONCAT(p.destination, p.source,  p.price, p.fid) LIKE %?1%", nativeQuery = true )
		List<Airlinedetails> findByKeyWord(String keyword);
	
		
		

		//@Query( value = "SELECT * from flightsbookings f where f.source like %:keywords%" , nativeQuery = true )
		@Query(value = "SELECT * FROM flightsbookings p WHERE CONCAT(p.destination, p.source,  p.price, p.fid) LIKE %?1%", nativeQuery = true )
		List<Airlinedetails> findByKeyWords(String keywords);
	
		
		
		
		
		
		
	//	@Query( value = "Select * from flightsbookings f where f.date like %")
		//List<Airlinedetails> findByDate(Date date);
		
		
		//@Query("from Airlinedetails where flightName=:flightName and source=:source and date=:date")
	//List<Airlinedetails> findByFlightNameAndSourceAndDate(String flightName, String source, Date date);

		List<Airlinedetails> findAllByFlightDate(Date flightDate);
		
		
		
		// public void remove(Airlinedetails details);

	}
	

	

