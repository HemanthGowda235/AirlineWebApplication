package com.airlinesystem.airlines.controller;

import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.airlinesystem.airlines.domain.Admin;
import com.airlinesystem.airlines.domain.User;
import com.airlinesystem.airlines.repository.UserRepository;
import com.airlinesystem.airlines.service.UserService;

@Controller
public class UserController {

	@Autowired
	private UserRepository repo;

	@Autowired
	private UserService service;

	
	  public UserController(UserService service) {
		super();
		this.service = service;
	}


	@RequestMapping("/login")
	  public ModelAndView showLoginForm(@ModelAttribute("user") User user ) { 
		  ModelAndView mav = new ModelAndView();
		 mav.setViewName("login");
	      return mav;
	      }
	 
	
	

	@PostMapping("/login")
	public String login(@ModelAttribute("user") User user) {
		User u = service.login(user.getEmail(), user.getPassword());
		System.out.println(u.getEmail());
		System.out.println(u.getPassword());
		if (Objects.nonNull(u)) {
			return "redirect:/flightbookings?done";

		} 
		else {
			return "redirect:/login?notvalid";
		}

	}

	@RequestMapping("/createuser")
	public ModelAndView newuser() {
		ModelAndView mv = new ModelAndView();
		mv.addObject("user", new User());
		mv.setViewName("createuser");
		return mv;

	}

	
  

	@RequestMapping("/save")
	public String saveUserDetails(@ModelAttribute("user") User user) {
		service.save(user);
		//return "redirect:/myprofile";
		return "redirect:/createuser?success";
	}

	@RequestMapping(value = ("/logout"))
	public String logout() {
		return "redirect:/login";
	}
	
	
	 // @RequestMapping("/index")
	//public String showUserList(Model model) {
	 // model.addAttribute("users", repo.findAll()); return "index"; }
	  
		/*
		 * @GetMapping("/edit/{id}") 
		 * public String showUpdateForm(@PathVariable("id")int id, Model model) { 
		 * User user= new User(); 
		 * user = service.get(id);
		 * model.addAttribute("user", user); 
		 * return "update-user";
		 * 
		 * }
		 */
	 
	
		/*
		 * @RequestMapping("/Myprofile") public ModelAndView viewProfile() {
		 * ModelAndView mv = new ModelAndView(); mv.addObject("user", new User());
		 * mv.setViewName("Myprofile"); return mv;
		 * 
		 * }
		 * 
		 * @RequestMapping("/save") public String saveDetails(@ModelAttribute("user")
		 * User user) { service.save(user); return "redirect:/Myprofile"; }
		 */
	
	/*
	 * @RequestMapping(value = ("/create"))
	 *  public String logouts() { return
	 * "redirect:/myprofile"; }
	 */
	
	/*
	 * @RequestMapping("/allusers") public ModelAndView profile1() { ModelAndView mv
	 * = new ModelAndView(); mv.setViewName("allusers"); return mv;
	 * 
	 * }
	 */
	
	
	
	@RequestMapping(value = "/allusers", method = RequestMethod.GET)
	public String listofUsers(Model model) {
		List<User> list= service.getAllUsers();
		model.addAttribute("userlist",list);
		return "allusers";
		
	}
	

	@GetMapping("/addUser")
    public String addUser(Model model) {
     List<User> listuser = service.getAllUsers();
        model.addAttribute("listuser", listuser);
        model.addAttribute("user", new User());
        return "addUser";
    }
 
    @RequestMapping(value = "/saveuser", method = RequestMethod.POST)
    public String saveUser(@ModelAttribute("user") User user) {
        service.save(user);
        return "redirect:/?edited";
    }
 
    @RequestMapping("/edituser/{id}")
    public ModelAndView editUser(@PathVariable(name = "id") int id) {
        ModelAndView mav = new ModelAndView("addUser");
        User user = service.get(id);
        mav.addObject("user", user);
        return mav;
        
    }
	
    @RequestMapping("/signout")
	  public ModelAndView showhomePage(@ModelAttribute("user") User user ) { 
		  ModelAndView ma = new ModelAndView();
		 ma.setViewName("login");
		// ma.addObject("admin", new Admin());
	      return ma;
	      }
    
    
    
    
    
	
	
	
	
}
