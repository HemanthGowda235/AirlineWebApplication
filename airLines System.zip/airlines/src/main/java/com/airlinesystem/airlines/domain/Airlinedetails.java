package com.airlinesystem.airlines.domain;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.airlinesystem.airlines.domain.User;

import org.springframework.format.annotation.DateTimeFormat;


@Entity
@Table(name="flightsbookings")
public class Airlinedetails {
	
	
	public Airlinedetails() {}
    
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	private String fid;
	private String flightName;
	private String source;
	private String destination;
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date flightDate;
	private int price;
	
	

	@ManyToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    @JoinTable(
            name="flight_user",
            joinColumns=@JoinColumn(name="airlinedetails_id",referencedColumnName = "id"),
            inverseJoinColumns = @JoinColumn(name="user_id" , referencedColumnName = "id"))
            List<User> users = new ArrayList<User>();


	public Airlinedetails(int id,String fid, String flightName, String source, String destination, Date flightDate, int price,
			List<User> users) {
		super();
		this.id = id;
		this.flightName = flightName;
		this.source = source;
		this.destination = destination;
		this.flightDate = flightDate;
		this.price = price;
		this.users = users;
		this.fid = fid;
	}

	
	
	
	
	
	
	
	
	
	
	
	public String getFid() {
		return fid;
	}












	public void setFid(String fid) {
		this.fid = fid;
	}












	public int getId() {
		return id;
	}





	public void setId(int id) {
		this.id = id;
	}





	public String getFlightName() {
		return flightName;
	}





	public void setFlightName(String flightName) {
		this.flightName = flightName;
	}





	public String getSource() {
		return source;
	}





	public void setSource(String source) {
		this.source = source;
	}





	public String getDestination() {
		return destination;
	}





	public void setDestination(String destination) {
		this.destination = destination;
	}





	public Date getFlightDate() {
		return flightDate;
	}





	public void setFlightDate(Date flightDate) {
		this.flightDate = flightDate;
	}





	public int getPrice() {
		return price;
	}





	public void setPrice(int price) {
		this.price = price;
	}





	public List<User> getUsers() {
		return users;
	}





	public void setUsers(List<User> users) {
		this.users = users;
	}





	public void addUser(User user) {
        this.users.add(user);
    }
    
    public void removeUser(User user) {
        this.users.remove(user);
    }




	public void addEmail(User currentUser) {
		// TODO Auto-generated method stub
		
	}



	public void cancelUser(User fuser) {
		 this.users.remove(fuser);
		
	}
	
}
	