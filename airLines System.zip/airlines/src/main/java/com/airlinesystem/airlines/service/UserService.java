package com.airlinesystem.airlines.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.airlinesystem.airlines.domain.User;
import com.airlinesystem.airlines.repository.UserRepository;

@Service
public class UserService  {
	
	
	public UserService(UserRepository repo) {
		super();
		this.repo = repo;
	}
	@Autowired
	private UserRepository repo;

	@Transactional
	public User login(String email, String password) {
		User user=repo.findByEmailAndPassword(email, password);
		return user;
	}

	public void save(User user) {
		 repo.save(user);
	}

	public User get(int id) {
		return repo.findById(id).get();
	}

	
	
     public List<User> getAllUsers(){
		return repo.findAll();
    	 
     }
   
     public User presentUser(){

	       final Authentication auth = SecurityContextHolder.getContext().getAuthentication();
	       String s = auth.getName();
	       User signin=repo.findByFirstName(s);
	       return  signin;
	    }
	
     public User updateUser(User user) {
		return repo.save(user);
    	 
     }

	
}