package com.airlinesystem.airlines.controller;

import java.util.Date;
import java.util.List;
import java.util.Objects;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.repository.query.Param;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.airlinesystem.airlines.AirlinesApplication;
import com.airlinesystem.airlines.domain.Admin;
import com.airlinesystem.airlines.domain.Airlinedetails;
import com.airlinesystem.airlines.domain.User;
import com.airlinesystem.airlines.service.AirlinedetailsService;
import com.airlinesystem.airlines.service.UserService;

@Controller
public class AirlinedetailsController {

	@Autowired
	private AirlinedetailsService service;
	
	@Autowired
	private UserService userservice;

	
	
	
	
	
	 public AirlinedetailsController(AirlinedetailsService service) {
		super();
		this.service = service;
	}


	 @RequestMapping("/airlinedetails")
		public ModelAndView userdetails() {
			ModelAndView mv = new ModelAndView();
			mv.addObject("airlinedetails", new Airlinedetails());
			mv.setViewName("airlinedetails");
			return mv;

		}
	 @RequestMapping(value = "/details", method = RequestMethod.POST)
	    public String saveUserdetails(@ModelAttribute("airlinedetails") Airlinedetails airlinedetails) {
	       service.save(airlinedetails);
	       
	       return "redirect:/airlinedetails?done";
	    }
	

		/*
		 * @RequestMapping("/flightuserdetails") public ModelAndView usersdetails() {
		 * ModelAndView mv = new ModelAndView(); mv.addObject("airlinedetails", new
		 * Airlinedetails()); mv.setViewName("flightuserdetails"); return mv;
		 * 
		 * 
		 * 
		 * }
		 */
		/*
		 * @RequestMapping("/flightsorting")
		 * 
		 * public String viewBookpage(Model model) { return
		 * findPaginated(1,"flightName", "asc", model); }
		 */
	 
	 
		
		
		 @RequestMapping(value = "/flightbookings", method = RequestMethod.GET) 
		  public String lists(Model model, @Param ("keyword" ) String keyword) {
		 List<Airlinedetails> list= service.getAll();
	  model.addAttribute("flightlist",list); 
	  model.addAttribute("keyword",keyword);
		  model.addAttribute("Title",keyword); 
		 if (keyword != null) {
		  model.addAttribute("flightlist", service.findByKeyWord(keyword)); 
		  
		  System.out.println("********************"+keyword);
		  }
		 // return "flightbookings";
		 
	 return findPaginated(1,"flightName", "asc", model);
		  
		  }
		 
	 
		  

		/*
		 * @RequestMapping(value = "/flightbookings", method = RequestMethod.GET) public
		 * String list(Model model, @Param ("keywords" ) String keywords) {
		 * List<Airlinedetails> list= service.getAll();
		 * model.addAttribute("flightlist",list);
		 * model.addAttribute("keyword",keywords);
		 * 
		 * 
		 * if (keywords != null) { model.addAttribute("flightlist",
		 * service.findByKeyWords(keywords)); // // //
		 * System.out.println("********************"+keywords); } // // return
		 * "flightbookings"; // return findPaginated(1,"flightName", "asc", model);
		 * 
		 * }
		 */
		 
		  
		  
		
		  
	 
		
		  
//		  @RequestMapping(value = "/flightbookings", method = RequestMethod.GET)
//		  public  String listofUser(Model model, @Param ("flightDate" )@DateTimeFormat(pattern
//		  = "yyyy-MM-dd")Date flightDate) {
//			  List<Airlinedetails> list=  service.getAll(); model.addAttribute("flightlist",list);
//		  model.addAttribute("flightDate",flightDate);
//		  
//		  if (flightDate != null) { 
//			  model.addAttribute("flightlist",
//	  service.findAllByFlightDate(flightDate));
//		  
//		  } return findPaginated(1,"flightName", "asc", model);
//          // return "flightbookings";
//		  
//	 }
		 
	 
	 @GetMapping("/book/{id}")
     public String bookflight(@PathVariable("id") int id)
     {
         User fuser = userservice.presentUser();
        String name= fuser.getEmail();
         int fid =  fuser.getId();
         Airlinedetails details = service.get(id);
	   
	  details.addUser( fuser);
	  service.save(details);
	  
	 // System.out.println("///////////////////////////////"+name);
	 // System.out.println("///////////////////////////////"+fid);
	 //  System.out.println("///////////////////////////////"+details);
	  
	  return "redirect:/flightbookings?done";
	  
	}
	 
	 
	 
	 
	 @Transactional
	 @GetMapping("/cancel/{id}")
     public String cancelflight(@PathVariable("id") int id)
     {
         User fuser = userservice.presentUser();
        //String name= fuser.getEmail();
       //  int fid =  fuser.getId();
         Airlinedetails details = service.get(id);
	String name =   details.getFlightName();
	
	
	  details.removeUser( fuser);
	  service.save(details);
	  
	  System.out.println("///////////////////////////////"+id);
	  System.out.println("++++++++++++++++++++++++"+name);
	 System.out.println("///////////////////////////////"+fuser);
	 //  System.out.println("///////////////////////////////"+details);
	  
	  return "redirect:/mybookings";
	  
	}
	 
	
//	 @GetMapping("/cancel/{id}")
//  public String cancelflight(@PathVariable("id") int id) { 
//	  Airlinedetails details = service.get(id);
//	  service.remove(details);
//  return "mybookings";
//  
//  }
	 
	 
	// @DeleteMapping("/cancel")
	    //public String deleteUserdetails(@ModelAttribute("airlinedetails") Airlinedetails airlinedetails) {
	     //  service.delete(airlinedetails);
	     //  
	     //  return "mybookings";
	   // }
	 
	 
	 
	 
	 
	 
	 
	 
	 

@RequestMapping(value = "/mybookings", method = RequestMethod.GET)
  public String myBookings(Model model) {
	 User user = userservice.presentUser();
	     int id = user.getId();
	List<Airlinedetails> mybookingsList = service.findById(id);
	    // List<Airlinedetails>  mybookingsList = service.findByDate(date);

	model.addAttribute("mybookingsList",mybookingsList);

    return "mybookings";	
	
	
}




@GetMapping("/page/{pageNo}")
public String findPaginated(@PathVariable (value = "pageNo") int pageNo, 
		@RequestParam("sortField") String sortField,
		@RequestParam("sortDir") String sortDir, Model model) {
	 int pageSize = 5;
	
	
	Page<Airlinedetails> page = service.findPaginated(pageNo, pageSize,sortField ,sortDir);
	List<Airlinedetails> lists = page.getContent();
	
	model.addAttribute("currentPage", pageNo);
	model.addAttribute("totalPages", page.getTotalPages());
	model.addAttribute("totalItems", page.getTotalElements());
	
	model.addAttribute("sortField", sortField);
	model.addAttribute("sortDir", sortDir);
	model.addAttribute("reverseSortDir", sortDir.equals("asc") ? "desc" :	"asc");
	
	model.addAttribute("lists", lists);
	
	

	return "flightbookings";
	
	
	
	



}















}

