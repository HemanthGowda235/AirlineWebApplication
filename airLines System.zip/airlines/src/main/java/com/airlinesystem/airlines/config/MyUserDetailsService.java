package com.airlinesystem.airlines.config;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.airlinesystem.airlines.domain.User;
import com.airlinesystem.airlines.repository.UserRepository;
import com.airlinesystem.airlines.service.UserPrincipal;


@Service
public class MyUserDetailsService implements UserDetailsService { 
	
	

	@Autowired
	private UserRepository repo;
	

@Override
@Transactional
public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
	 User user = repo.findByEmail(email);
	 System.out.println(user);
        if (user == null) {
            throw new UsernameNotFoundException("Could not find user with that email");
        }
    return new UserPrincipal(user);
    
}
}
